//Code By MrTusarRX Fixed Lgl Php With Src


<?php
// Check if username and password parameters are provided
if (isset($_GET['username']) && isset($_GET['password'])) {
    // Retrieve username and password from the GET parameters
    $username = $_GET['username'];
    $password = $_GET['password'];

    // Base64 decode the username and password if they were encoded before sending
    $username = base64_decode($username);
    $password = base64_decode($password);


    $validUsername = 'Tusar'; // Replace 'your_username' with the actual valid username
    $validPassword = '123'; // Replace 'your_password' with the actual valid password


    if ($username === $validUsername && $password === $validPassword) {

        $response = array('code' => '1', 'message' => 'Authentication successful');
    } else {

        $response = array('code' => '0', 'message' => 'Authentication failed');
    }
} else {
    $response = array('code' => '-1', 'message' => 'Username or password parameter is missing');
}

// Output the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>